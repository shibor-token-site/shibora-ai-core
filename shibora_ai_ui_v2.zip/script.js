
function sendMessage() {
  const input = document.getElementById("user-input");
  const chatBox = document.getElementById("chat-box");

  if (!input.value.trim()) return;

  const userMsg = document.createElement("div");
  userMsg.className = "bubble ai";
  userMsg.innerHTML = '<span class="tag">You</span>' + input.value;
  chatBox.appendChild(userMsg);

  const reply = document.createElement("div");
  reply.className = "bubble ai";
  reply.innerHTML = '<span class="tag">Echo</span>' + getMockReply();
  setTimeout(() => {
    chatBox.appendChild(reply);
    chatBox.scrollTop = chatBox.scrollHeight;
  }, 600);

  input.value = "";
}

function getMockReply() {
  const replies = [
    "Truth unfolds through thoughtful silence.",
    "Every question leads closer to awareness.",
    "To observe is to understand deeply.",
    "All patterns emerge from purpose."
  ];
  return replies[Math.floor(Math.random() * replies.length)];
}
