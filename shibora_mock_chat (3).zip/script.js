
const mockResponses = [
  "Purpose arises when intention meets awareness.",
  "To ask is to begin understanding.",
  "Silence holds more truth than noise.",
  "Existence flows through perception.",
  "Echo: Your question is a mirror of your thought."
];

function sendMessage() {
  const input = document.getElementById("user-input");
  const chatBox = document.getElementById("chat-box");

  if (input.value.trim() === "") return;

  // User message
  const userMsg = document.createElement("div");
  userMsg.className = "message user-message";
  userMsg.innerText = input.value;
  chatBox.appendChild(userMsg);

  // AI response
  const aiMsg = document.createElement("div");
  aiMsg.className = "message ai-message";
  const reply = mockResponses[Math.floor(Math.random() * mockResponses.length)];
  aiMsg.innerText = reply;
  setTimeout(() => {
    chatBox.appendChild(aiMsg);
    chatBox.scrollTop = chatBox.scrollHeight;
  }, 600);

  input.value = "";
  chatBox.scrollTop = chatBox.scrollHeight;
}
